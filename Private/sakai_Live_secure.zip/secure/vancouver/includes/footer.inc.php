<?php

// all pages footer.inc

?>

				</div><!-- end containerbg -->
		
		
		<!-- begin footer -->
		<div class="clear">

		</div>
		<div id="blackline">
		</div>
		<div class="clear">
		</div>
		<div id="bottompadding"></div>
	
	<!-- copyright notice -->
	<div id="copyright"><div>
		copyright 2006 Sakai Project
		<br /><span class=small>contact <a href="mailto:sakaiproject_webmaster@umich.edu">

		--Webmaster</a></span></div>
	</div>
	<!--end  copyright notice -->

	<div class="clear"><br /><br /><br />	</div>
	<!--end  footer -->

</div><!-- end outerleft -->
</div><!-- end container -->
</div><!-- end center -->


</body>
</html>