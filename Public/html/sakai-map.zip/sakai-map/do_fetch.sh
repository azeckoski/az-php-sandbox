php -q fetchPage.php https://souurce.sakaiproject.org/contrib/foundation/sakai-map/data.xml
